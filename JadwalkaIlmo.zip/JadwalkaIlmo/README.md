# Jadwalka Ilmo — Android Alarm App

App Android dhab ah: wuu wacayaa xitaa marka app-ku xiran yahay ama taleefanku qufulan yahay.

## Sida loo dhiso APK (Android Studio)
1. Fur Android Studio → **Open** → dooro folder-kan `JadwalkaIlmo`.
2. Sug Gradle sync (internet ayaa loo baahan yahay markii ugu horreysa).
3. **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
4. APK-ga waxaa laga helayaa `app/build/outputs/apk/debug/app-debug.apk` → u dir taleefanka (WhatsApp / USB) oo rakib.

## Markii la rakibo (taleefanka)
- Ogolow **Notifications**.
- Ogolow **Alarms & reminders** (Settings → Apps → Jadwalka Ilmo → Alarms & reminders) — app-ku wuu kuu furayaa haddii loo baahdo.
- Ogolow **battery: Unrestricted / Don't optimize** (app-ku wuu weydiinayaa).
- Taleefannada Xiaomi/Oppo/Vivo/Huawei: Settings → Apps → Jadwalka Ilmo → ogolow **Autostart** iyo **Display pop-up windows while running in background**.

## Sida uu u shaqeeyo
- Fur app-ka → dooro magacaaga.
- App-ku wuxuu ku dhigayaa alaarmka shaqadaada xigta (AlarmManager, exact). Markasta oo mid wacdo, kan xiga ayaa si toos ah loo dhigayaa.
- Waqtiga shaqada: shaashad buuxda (xitaa taleefanku qufulan), cod alaarm oo dheer (volume-ka alaarmka oo buuxa), gariir. Badhamada: **Waan ogahay** / **5 daqiiqo dib**.
- Markii taleefanka la shido mar kale, alaarmku si toos ah ayuu dib ugu dhigmaa.

## Jadwalka
Wuxuu ku jiraa `Schedule.kt` (native) iyo `assets/index.html` (muuqaalka). Toddobaadka 1 = Sabti 17 Okt 2026, kadibna way isku beddelayaan.
Isbeddel: Arbaco subax iyo Arbaco habeen → Ciise.

## Heesta "يا أبي"
Bogga jadwalka waxaa ku yaal badhanka 🎵 — wuxuu furayaa heesta: muuqaal fardo/geedo/qorrax-dhac, muusig cuud iyo durbaan (ku dhex jira `assets/index.html`), iyo ereyada oo taleefanku ku akhriyo cod Carabi ah (Android TextToSpeech, Locale ar).
Haddii codku Carabi ahayn: Settings → System → Languages → Text-to-speech → Google Speech Services → Install voice data → العربية.
